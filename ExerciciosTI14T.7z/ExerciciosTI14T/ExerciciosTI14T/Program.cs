﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExerciciosTI14T
{
    class Program
    {
        static void Main(string[] args)
        {
            ControlExercicios control = new ControlExercicios();
            control.Executar();
            Console.ReadLine();//Manter o prompt aberto
        }//Fim do método main
    }//Fim da Classe
}//Fim do Projeto
