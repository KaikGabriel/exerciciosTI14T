# exerciciosTI14T
